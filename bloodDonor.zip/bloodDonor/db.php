<?php
$conn = mysqli_connect("localhost", "root", "", "blood_donor");

if (!$conn ) {
    die("Connection failed");
}
?>
